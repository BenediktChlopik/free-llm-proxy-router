package config

import (
	"fmt"
	"strings"
)

// ProviderConfig holds all configuration for a single provider.
type ProviderConfig struct {
	ID       string `mapstructure:"id"`
	Name     string `mapstructure:"name"`
	BaseURL  string `mapstructure:"base_url"`
	Priority int    `mapstructure:"priority"`

	// EnableEnv is an optional boolean environment variable for providers that
	// do not need an API key (for example, local inference servers).
	EnableEnv string `mapstructure:"enable_env"`

	// ForceEnabled is an internal override used by explicit scan commands. It is
	// intentionally not decoded from configuration files.
	ForceEnabled bool   `mapstructure:"-"`
	Timeout      string `mapstructure:"timeout"`

	// Auth: either api_key_env (env var name) or api_key (literal, use sparingly)
	APIKeyEnv  string `mapstructure:"api_key_env"`
	APIKey     string `mapstructure:"api_key"`
	AuthHeader string `mapstructure:"auth_header"` // default: "Authorization"
	AuthPrefix string `mapstructure:"auth_prefix"` // default: "Bearer "

	// ExtraHeaders are injected on every request to this provider.
	// Example: {"HTTP-Referer": "...", "X-Title": "...", "Cohere-Version": "..."}
	ExtraHeaders map[string]string `mapstructure:"extra_headers"`

	// TierType distinguishes traditional rate-limited free tiers ("free")
	// from credit-based systems ("credit").
	TierType string `mapstructure:"tier_type"` // "free" | "credit"

	// RateLimitNotes is a human-readable annotation; not used in logic.
	RateLimitNotes string `mapstructure:"rate_limit_notes"`

	// NativeFeatures describes provider-native capabilities to exploit.
	NativeFeatures NativeFeatures `mapstructure:"native_features"`

	// Discovery configures how free models are enumerated.
	Discovery DiscoveryConfig `mapstructure:"discovery"`

	// PreferredVolumeModel is used by StrategyVolume to pick highest-RPD model.
	PreferredVolumeModel string `mapstructure:"preferred_volume_model"`
}

// NativeFeatures lists provider-native request capabilities.
type NativeFeatures struct {
	// ServiceTier is sent as-is in the request body (Groq: "auto").
	ServiceTier string `mapstructure:"service_tier"`

	// FreeRouterModel is the model ID for ultimate fallback (OpenRouter: "openrouter/free").
	FreeRouterModel string `mapstructure:"free_router_model"`
}

// DiscoveryConfig controls how the scanner finds free models for a provider.
type DiscoveryConfig struct {
	// ModelsEndpoint is the path or full URL to list models.
	ModelsEndpoint string `mapstructure:"models_endpoint"`

	// AllFree marks all returned models as free (e.g. Groq, Cerebras).
	AllFree bool `mapstructure:"all_free"`

	// FreeDetectField is a dot-path field to check for free detection (OpenRouter).
	FreeDetectField string `mapstructure:"free_detect_field"`
	// FreeDetectValue is the expected value (e.g. "0").
	FreeDetectValue string `mapstructure:"free_detect_value"`

	// FreeMarkers are model ID suffixes that signal free models (e.g. ":free").
	FreeMarkers []string `mapstructure:"free_markers"`

	// ProbeForFree: if true, make a test call to verify uncertain free status.
	ProbeForFree bool `mapstructure:"probe_for_free"`

	// SkipModelsEndpoint: use an alternative discovery source (HuggingFace).
	SkipModelsEndpoint bool `mapstructure:"skip_models_endpoint"`

	// HubAPIFilters is passed to the HF Hub API for model filtering.
	HubAPIFilters string `mapstructure:"hub_api_filters"`
}

// IsEnabled derives provider availability from the current environment instead
// of a duplicated YAML boolean. Providers with api_key_env are enabled only
// when at least one key is present. Providers without an API key requirement
// are enabled by default unless an explicit EnableEnv toggle is configured.
func (p *ProviderConfig) IsEnabled() bool {
	if p == nil {
		return false
	}
	if p.ForceEnabled {
		return true
	}
	if p.EnableEnv != "" {
		switch strings.ToLower(strings.TrimSpace(lookupEnv(p.EnableEnv))) {
		case "1", "true", "yes", "on":
			return true
		default:
			return false
		}
	}
	if p.APIKeyEnv != "" {
		return len(p.AllKeys()) > 0
	}
	return true
}

// ResolvedAPIKey returns the bare API key (no header name, no prefix).
// Useful for providers that pass the key as a query parameter (e.g. Gemini).
// Lookup order: real env var → dotenv file → literal api_key field.
func (p *ProviderConfig) ResolvedAPIKey() string {
	if p.APIKeyEnv != "" {
		if v := lookupEnv(p.APIKeyEnv); v != "" {
			return v
		}
	}
	return p.APIKey
}

// ResolvedAuth returns the effective API key and auth header values.
// The env var takes precedence over the literal key.
func (p *ProviderConfig) ResolvedAuth() (header, value string) {
	key := p.APIKey
	if p.APIKeyEnv != "" {
		if v := lookupEnv(p.APIKeyEnv); v != "" {
			key = v
		}
	}
	h := p.AuthHeader
	if h == "" {
		h = "Authorization"
	}
	prefix := p.AuthPrefix
	if prefix == "" && h == "Authorization" {
		prefix = "Bearer "
	}
	return h, prefix + key
}

// AllKeys returns all API keys available for this provider in priority order.
// It auto-discovers numbered variants of the base env var up to _9:
//
//	GROQ_API_KEY, GROQ_API_KEY_2, GROQ_API_KEY_3, ...
//
// Add GROQ_API_KEY_2=gsk_... to .env to pool keys across multiple accounts.
// The proxy rotates to the next slot automatically on 429.
func (p *ProviderConfig) AllKeys() []string {
	var keys []string
	if p.APIKey != "" {
		keys = append(keys, p.APIKey)
	}
	if p.APIKeyEnv != "" {
		if v := lookupEnv(p.APIKeyEnv); v != "" {
			keys = append(keys, v)
		}
		for i := 2; i <= 9; i++ {
			if v := lookupEnv(fmt.Sprintf("%s_%d", p.APIKeyEnv, i)); v != "" {
				keys = append(keys, v)
			}
		}
	}
	return keys
}

// MissingKey reports whether the provider expects an API key (api_key_env is
// set) but none is configured. Keyless providers such as local Ollama never miss one.
func (p *ProviderConfig) MissingKey() bool {
	return p.APIKeyEnv != "" && len(p.AllKeys()) == 0
}

// NumKeys returns the number of API keys available for this provider.
func (p *ProviderConfig) NumKeys() int {
	return len(p.AllKeys())
}
